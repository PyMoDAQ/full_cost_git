from django.apps import AppConfig


class ImplantConfig(AppConfig):
    name = 'implant'
