from django.apps import AppConfig


class FabConfig(AppConfig):
    name = 'fab'
