from django.apps import AppConfig


class OsmConfig(AppConfig):
    name = 'osm'
