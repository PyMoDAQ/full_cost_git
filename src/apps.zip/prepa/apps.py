from django.apps import AppConfig


class PrepaConfig(AppConfig):
    name = 'prepa'
