from django.apps import AppConfig


class OspConfig(AppConfig):
    name = 'osp'
