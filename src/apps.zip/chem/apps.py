from django.apps import AppConfig


class ChemConfig(AppConfig):
    name = 'chem'
