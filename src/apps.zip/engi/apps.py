from django.apps import AppConfig


class EngiConfig(AppConfig):
    name = 'engi'
