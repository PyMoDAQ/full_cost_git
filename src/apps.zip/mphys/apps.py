from django.apps import AppConfig


class MphysConfig(AppConfig):
    name = 'mphys'
