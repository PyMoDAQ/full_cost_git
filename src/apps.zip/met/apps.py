from django.apps import AppConfig


class MetConfig(AppConfig):
    name = 'met'
