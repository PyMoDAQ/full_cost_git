from django.apps import AppConfig


class ImagConfig(AppConfig):
    name = 'imag'
